package com.example.bbddandroid.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Clase que crea y actualiza la base de datos SQLite.
 * Tabla: personas (id INTEGER PRIMARY KEY, nombre TEXT)
 */
class PersonaDbHelper(context: Context) : SQLiteOpenHelper(
    context,
    DATABASE_NAME,
    null,
    DATABASE_VERSION
) {

    override fun onCreate(db: SQLiteDatabase) {
        // Sentencia SQL para crear la tabla
        val sqlCreateTable = """
            CREATE TABLE $TABLE_PERSONAS (
                $COL_ID INTEGER PRIMARY KEY,
                $COL_NOMBRE TEXT NOT NULL,
                $COL_CONTRASENHA TEXT NOT NULL
            )
        """.trimIndent()

        db.execSQL(sqlCreateTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Para este ejemplo, simplemente borramos y volvemos a crear
        db.execSQL("DROP TABLE IF EXISTS $TABLE_PERSONAS")
        onCreate(db)
    }

    companion object {
        const val DATABASE_NAME = "personas.db"
        const val DATABASE_VERSION = 1

        const val TABLE_PERSONAS = "personas"
        const val COL_ID = "id"
        const val COL_NOMBRE = "nombre"
    }
}